<?php
$UTF8_TO_ASCII[0x21] = array(

);
