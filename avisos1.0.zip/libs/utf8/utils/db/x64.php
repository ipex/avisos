<?php
$UTF8_TO_ASCII[0x64] = array(

);
